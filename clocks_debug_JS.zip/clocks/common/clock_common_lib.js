BigNumber = {
  toString: function (o, radix) {
    if (radix == null) {
      radix = 10;
    }
    if (o instanceof java.math.BigInteger) {
      return util.toString(o, radix);
    } else if (o instanceof Number || typeof(o) == "number") {
      return o.toString(radix);
    }
    return o.toString();
  },
  
}  //BigNumber prototype                                                                                                                                                             

                                                     