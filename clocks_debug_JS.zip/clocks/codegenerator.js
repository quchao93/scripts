scriptApi.logWarning("There are generation starter scripts in the processor data. Therefore clock_config.c/h are not generated.");
// util functions implemented in the tool
var util = Java.type("com.nxp.swtools.utils.scripting.JSUtils");
// load common objects
scriptApi.requireScript("common/clock_common_lib.js");
// for debug purposes
scriptApi.requireScript("debug.js");
