import os, re, sys
import shutil
from optparse import OptionParser

# Set some general path
PATH = sys.path[0]
SOC_PATH = '/../../chipmodel/soc/kinetis/'
OUTPUT_PATH = '/../../npi-data/kinetis/'

exception_list = []

# Parser command parameter, need a destination path here
parser = OptionParser()
parser.add_option('-n', '--npi', action = 'store', type = 'string', dest = 'npiname', help = 'specify target npi')
parser.add_option('-s', '--startnpi', action = 'store', type = 'string', dest = 'startnpi', help = 'specify start npi')
parser.add_option('-p', '--path', action = "store", type = 'string', dest = 'destpath', help = "destination path")
parser.add_option('-t', '--type', action = "store", type = 'string', dest = 'batchtype', help = "header file type: memmap, feature, linker, svd")

(options, args) = parser.parse_args()

# Get destination path
if options.destpath == None:
	DEST_PATH = 'E:/sdk_2.0/mcu-sdk-2.0/devices/'
else:
	DEST_PATH = options.destpath

# Get header file type
if options.batchtype == None:
	batch_type = ['memmap', 'feature', 'linker', 'svd']
else:
	batch_type = options.batchtype.split(',')

# Get NPI list
if options.npiname == None:
	npi_list = os.listdir(PATH + SOC_PATH)
	if options.startnpi != None:
		for i in range(len(npi_list)):
			if (i == len(npi_list)-1):
				print 'Input NPI name ' + options.startnpi + ' can not be recognized !'
				exit()
			if npi_list[i] == options.startnpi:
				npi_list = npi_list[i:len(npi_list)]
				break
else:
	NPIS = os.listdir(PATH + SOC_PATH)
	npi_list = options.npiname.split(',')
	for npi in npi_list:
		if npi not in NPIS:
			print 'Input NPI name ' + npi + ' can not be recognized !'
			exit()

# Create log files
log_file = open('copy_files_log.txt', 'w')
toolchains = ['iar', 'arm', 'gcc', 'mcuxpresso']

for NPI in npi_list:
# Find batch for SOC
	BATCH_DIR = '/batches/memory_maps/sdk/'
	if os.path.isdir(PATH + SOC_PATH + NPI + BATCH_DIR):
		files = os.listdir(PATH + SOC_PATH + NPI + BATCH_DIR)
		for file in files:
			if (('all' not in file) and ('.gbat' in file)):
				CPU =  file.split('.')[0]
				NPI = NPI.upper()
				CPU = CPU.upper()
				# Dual core SOCs
				if ('_' in CPU) and ('WIFI' not in CPU):
					CPU_SDK = CPU.split('_')[0]
					CPU_WS = CPU
				# WS part
				elif CPU.endswith('WS'):
					CPU_SDK = CPU
					CPU_WS = CPU.split('WS')[0]
				# Normal part
				else:
					CPU_SDK = CPU
					CPU_WS = CPU
				log_file.write(NPI + ' ' + CPU + '\n')
				# Copy soc.h and test files from chipmodel to sdk repo
				if not os.path.isdir(DEST_PATH + CPU_SDK):
					log_file.write('Folder ' + CPU_SDK + ' does not exist in destination path\n')
					continue
				if os.path.isdir(DEST_PATH + CPU_SDK) and (CPU_SDK not in exception_list):
					# memmap files
					if 'memmap' in batch_type:
						# shutil.copy(PATH + OUTPUT_PATH + NPI + '/ksdk/' + CPU + '/' + CPU_WS + '.h', DEST_PATH + CPU_SDK)
						# shutil.copy(PATH + OUTPUT_PATH + NPI + '/ksdk/' + CPU + '/' + 'fsl_device_registers.h', DEST_PATH + CPU_SDK)
						# shutil.copy(PATH + OUTPUT_PATH + NPI + '/ksdk/' + CPU + '/system_' + CPU_WS + '.c', DEST_PATH + CPU_SDK)
						# shutil.copy(PATH + OUTPUT_PATH + NPI + '/ksdk/' + CPU + '/system_' + CPU_WS + '.h', DEST_PATH + CPU_SDK)
						# shutil.copy(PATH + OUTPUT_PATH + NPI + '/ksdk_test_files/Test_' + CPU + '_registers.bat', DEST_PATH + CPU_SDK)
						# shutil.copy(PATH + OUTPUT_PATH + NPI + '/ksdk_test_files/Test_' + CPU + '_CMSIS.c', DEST_PATH + CPU_SDK)
						for toolchain in toolchains:	
							if not os.path.isdir(DEST_PATH + CPU_SDK + '/' + toolchain):
								log_file.write(CPU_SDK + ' ' + toolchain + ' folder does not exist in destination folder\n')
							if (os.path.isdir(PATH + OUTPUT_PATH + NPI + '/ksdk/' + CPU + '/' + toolchain) and os.path.isdir(DEST_PATH + CPU_SDK + '/' + toolchain)):
								docs = os.listdir(PATH + OUTPUT_PATH + NPI + '/ksdk/' + CPU + '/' + toolchain)
								for doc in docs:
									if (doc.endswith('.s') or doc.endswith('.S') or doc.endswith('.c') or doc.endswith('.cpp')):
										shutil.copy(PATH + OUTPUT_PATH + NPI + '/ksdk/' + CPU + '/' + toolchain + '/' + doc, DEST_PATH + CPU_SDK + '/' + toolchain)
						log_file.write('copy memmap files done\n')
					# feature file
					if 'feature' in batch_type:
						shutil.copy(PATH + OUTPUT_PATH + NPI + '/ksdk/' + CPU + '/' + CPU_WS + '_features.h', DEST_PATH + CPU_SDK)
						log_file.write('copy feature file done\n')
					# linker files
					if 'linker' in batch_type:
						for toolchain in toolchains:	
							if not os.path.isdir(DEST_PATH + CPU_SDK + '/' + toolchain):
								log_file.write(CPU_SDK + ' ' + toolchain + ' folder does not exist in destination folder\n')
							if (os.path.isdir(PATH + OUTPUT_PATH + NPI + '/ksdk/' + CPU + '/' + toolchain) and os.path.isdir(DEST_PATH + CPU_SDK + '/' + toolchain)):
								docs = os.listdir(PATH + OUTPUT_PATH + NPI + '/ksdk/' + CPU + '/' + toolchain)
								for doc in docs:
									if ((doc.endswith('.s') == 0) and (doc.endswith('.S') == 0) and (doc.endswith('.c') == 0) and (doc.endswith('.cpp') == 0)):
										shutil.copy(PATH + OUTPUT_PATH + NPI + '/ksdk/' + CPU + '/' + toolchain + '/' + doc, DEST_PATH + CPU_SDK + '/' + toolchain)
								log_file.write(toolchain + ' linker files copy done\n')
					# svd file
					if 'svd' in batch_type:
						shutil.copy(PATH + OUTPUT_PATH + NPI + '/ksdk/' + CPU + '/' + CPU_WS + '.xml', DEST_PATH + CPU_SDK)
						log_file.write('copy svd file done\n')
					# device.meta file
					if 'meta' in batch_type:
						shutil.copy(PATH + OUTPUT_PATH + NPI + '/ksdk/' + CPU + '/' + CPU + '_device.meta', DEST_PATH + CPU_SDK)
						log_file.write('copy svd file done\n')
	log_file.write('\n')
log_file.close()
						
