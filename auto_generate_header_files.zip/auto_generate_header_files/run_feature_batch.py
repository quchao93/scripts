import os, re, sys
import shutil
from optparse import OptionParser

# Set chipmodel environment variables
PATH = sys.path[0]
ROOT_PATH = PATH + '/../../'
os.environ['APIF_PRG_PATH'] = ROOT_PATH + '/' + 'agen'
os.environ['APIF_DB_PATH'] = ROOT_PATH + '/' + 'chipmodel'
os.environ['OUTPUTS_PATH'] = ROOT_PATH + '/' + 'npi-data'

# Set some general path
SOC_PATH = '/chipmodel/soc/kinetis/'

# Parser command parameter, need a destination path here
parser = OptionParser()
parser.add_option('-n', '--npi', action = 'store', type = 'string', dest = 'npiname', help = 'specify target npi')
parser.add_option('-s', '--startnpi', action = 'store', type = 'string', dest = 'startnpi', help = 'specify start npi')

(options, args) = parser.parse_args()

# Get NPI list
if options.npiname == None:
	npi_list = os.listdir(ROOT_PATH + SOC_PATH)
	if options.startnpi != None:
		for i in range(len(npi_list)):
			if (i == len(npi_list)-1):
				print 'Input NPI name ' + options.startnpi + ' can not be recognized !'
				exit()
			if npi_list[i] == options.startnpi:
				npi_list = npi_list[i:len(npi_list)]
				break
else:
	NPIS = os.listdir(ROOT_PATH + SOC_PATH)
	npi_list = options.npiname.split(',')
	for npi in npi_list:
		if npi not in NPIS:
			print 'Input NPI name ' + npi + ' can not be recognized !'
			exit()

# Create folder for generate error logs
if os.path.isdir(PATH + '/generate_feature_error_logs'):
	shutil.rmtree(PATH + '/generate_feature_error_logs')
os.mkdir(PATH + '/generate_feature_error_logs')

for NPI in npi_list:
# Find batch for SOC
	BATCH_DIR = '/batches/features/'
	if os.path.isdir(ROOT_PATH + SOC_PATH + NPI + BATCH_DIR):
		files = os.listdir(ROOT_PATH + SOC_PATH + NPI + BATCH_DIR)
		for file in files:
			if (('all' not in file) and ('.gbat' in file)):
				generate_error = '0'
				CPU =  file.split('.')[0]
				NPI = NPI.upper()
				CPU = CPU.upper()
				# Run memmap batch to generate soc.h and test files
				print 'Generating ' + NPI + ' ' + CPU + ' feature file'
				os.system(ROOT_PATH + '/agen/agen64 ' + ROOT_PATH + SOC_PATH + NPI + BATCH_DIR + file + ' > ' + PATH + '/generate_feature_error_logs/' + NPI + '_' + CPU + '_log 2>&1')
				# Check log file
				outlog = open(PATH + '/generate_feature_error_logs/' + NPI + '_' + CPU + '_log')
				lines = outlog.readlines()
				for line in lines:
					if ('agen: Total:' in line) and ('ERRORS' in line):
						generate_error = '1'
						print 'Errors occur when generating ' + NPI + ' ' + CPU + ' feature file, please see detail information in folder generate_feature_error_logs'
				if generate_error == '0':
					outlog.close()
					os.remove(PATH + '/generate_feature_error_logs/' + NPI + '_' + CPU + '_log')
					print 'Generate ' + NPI + ' ' + CPU + ' feature file successfully'
if not os.listdir(PATH + '/generate_feature_error_logs'):
	shutil.rmtree(PATH + '/generate_feature_error_logs')
						
