import os, re, sys, time, math
import time
from optparse import OptionParser

# Parser command parameter, need sdk repo path here
parser = OptionParser()
parser.add_option('-p', '--path', action = "store", type = 'string', dest = 'sdkpath', help = "sdk repo path")
parser.add_option('-t', '--type', action = "store", type = 'string', dest = 'batchtype', help = "header file type: memmap, feature, linker, svd")
(options, args) = parser.parse_args()
if options.sdkpath == None:
	SDK_PATH = 'E:/sdk_2.0/mcu-sdk-2.0/'
else:
	SDK_PATH = options.sdkpath
if options.batchtype == None:
	batch_type = ['memmap', 'feature', 'linker', 'svd']
else:
	batch_type = options.batchtype.split(',')

timeStart = time.time()
print "Start time: " + time.ctime(timeStart)

if 'memmap' in batch_type:
	print 'Generate sdk soc.h for all SOCs in sdk devices folder'
	os.system('run_memmap_batch.py -t sdk')
if 'feature' in batch_type:
	print 'Generate feature file for all SOCs in sdk devices folder'
	os.system('run_feature_batch.py')
if 'linker' in batch_type:
	print 'Generate sdk linker files for all SOCs in sdk devices folder'
	os.system('run_linker_batch.py -t sdk')
if 'svd' in batch_type:
	print 'Generate svd files for all SOCs in sdk devices folder'
	os.system('run_svd_batch.py')

print 'Copy header files and test files from chipmodel repo to sdk repo'
os.system('build_test.py -p' + SDK_PATH + '/devices')

def changeTimeFormat(allTime):
    day = 24*60*60
    hour = 60*60
    min = 60
    if allTime <60:
        return  "%d sec"%math.ceil(allTime)
    elif  allTime > day:
        days = divmod(allTime,day)
        return "%d days, %s"%(int(days[0]),changeTime(days[1]))
    elif allTime > hour:
        hours = divmod(allTime,hour)
        return '%d hours, %s'%(int(hours[0]),changeTime(hours[1]))
    else:
        mins = divmod(allTime,min)
        return "%d mins, %d sec"%(int(mins[0]),math.ceil(mins[1]))
print "Start time: " + time.ctime(timeStart)
timeEnd = time.time()
print "End time: " + time.ctime(timeEnd)
print "Total running time: " + changeTimeFormat(timeEnd - timeStart)