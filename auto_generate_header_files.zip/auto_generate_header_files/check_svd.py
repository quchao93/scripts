import os, re, sys
import shutil
from optparse import OptionParser

SDK_PATH = 'E:/sdk_2.0/mcu-sdk-2.0/devices/'
SOC = os.listdir(SDK_PATH)
for CPU in SOC:
	if ('.git' not in CPU) and ('devices' not in CPU):
		files = os.listdir(SDK_PATH + CPU)
		for file in files:
			if '.xml' in file:
				print file

# PATH = sys.path[0]
# SOC_PATH = '/../../chipmodel/soc/kinetis/'
# OUTPUT_PATH = '/../../npi-data/kinetis/'
# MEM_BATCH_DIR = '/batches/memory_maps/sdk/'

# exception_list = []

# parser = OptionParser()
# parser.add_option('-p', '--path', action = "store", type = 'string', dest = 'destpath', help = "destination path")
# (options, args) = parser.parse_args()
# if options.destpath == None:
	# DEST_PATH = 'E:/sdk_2.0/mcu-sdk-2.0/devices/'
# else:
	# DEST_PATH = options.destpath

# DIRS = os.listdir(PATH + SOC_PATH)

# for NPI in DIRS:
	# if os.path.isdir(PATH + SOC_PATH + NPI + MEM_BATCH_DIR):
		# files = os.listdir(PATH + SOC_PATH + NPI + MEM_BATCH_DIR)
		# for file in files:
			# if (('all' not in file) and ('.gbat' in file)):
				# CPU =  file.split('.')[0]
				# NPI = NPI.upper()
				# CPU = CPU.upper()
				# if os.path.isdir(PATH + OUTPUT_PATH + NPI + '/ksdk_test_files/'):
					# a = os.listdir(PATH + OUTPUT_PATH + NPI + '/ksdk_test_files/')
					# for b in a:
						# if b.endswith('device_registers.bat'):
							# os.remove(PATH + OUTPUT_PATH + NPI + '/ksdk_test_files/' + b)
						
