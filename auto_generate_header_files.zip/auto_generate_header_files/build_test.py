import os, re, sys
import shutil
from optparse import OptionParser

# Set some general path
PATH = sys.path[0]
SOC_PATH = '/../../chipmodel/soc/kinetis/'
OUTPUT_PATH = '/../../npi-data/kinetis/'
MEM_BATCH_DIR = '/batches/memory_maps/sdk/'

exception_list = []

# Parser command parameter, need a destination path here
parser = OptionParser()
parser.add_option('-p', '--path', action = "store", type = 'string', dest = 'destpath', help = "destination path")
(options, args) = parser.parse_args()
if options.destpath == None:
	DEST_PATH = 'E:/sdk_2.0/mcu-sdk-2.0/devices/'
else:
	DEST_PATH = options.destpath

# Create folder for build error logs
if os.path.isdir(PATH + '/build_error_logs'):
	shutil.rmtree(PATH + '/build_error_logs')
os.mkdir(PATH + '/build_error_logs')

# Find all NPI SOCs
DIRS = os.listdir(PATH + SOC_PATH)
# For debug and test
# DIRS = ['ultra', 'kl80']

for NPI in DIRS:
# Find batch for SOC
	if os.path.isdir(PATH + SOC_PATH + NPI + MEM_BATCH_DIR):
		files = os.listdir(PATH + SOC_PATH + NPI + MEM_BATCH_DIR)
		for file in files:
			if (('all' not in file) and ('.gbat' in file)):
				CPU =  file.split('.')[0]
				NPI = NPI.upper()
				CPU = CPU.upper()
				# Dual core SOCs
				if ('_' in CPU) and ('WIFI' not in CPU):
					CPU_SDK = CPU.split('_')[0]
					CPU_WS = CPU
				# WS part
				elif CPU.endswith('WS'):
					CPU_SDK = CPU
					CPU_WS = CPU.split('WS')[0]
				# Normal part
				else:
					CPU_SDK = CPU
					CPU_WS = CPU
				# Copy soc.h and test files from chipmodel to sdk repo
				if os.path.isdir(DEST_PATH + CPU_SDK) and (CPU_SDK not in exception_list):
					# shutil.copy(PATH + OUTPUT_PATH + NPI + '/ksdk/' + CPU + '/' + CPU_WS + '.h', DEST_PATH + CPU_SDK)
					# shutil.copy(PATH + OUTPUT_PATH + NPI + '/ksdk/' + CPU + '/system_' + CPU_WS + '.c', DEST_PATH + CPU_SDK)
					# shutil.copy(PATH + OUTPUT_PATH + NPI + '/ksdk/' + CPU + '/system_' + CPU_WS + '.h', DEST_PATH + CPU_SDK)
					# shutil.copy(PATH + OUTPUT_PATH + NPI + '/ksdk/' + CPU + '/arm/startup_' + CPU_WS + '.s', DEST_PATH + CPU_SDK + '/arm')
					# shutil.copy(PATH + OUTPUT_PATH + NPI + '/ksdk/' + CPU + '/iar/startup_' + CPU_WS + '.s', DEST_PATH + CPU_SDK + '/iar')
					# shutil.copy(PATH + OUTPUT_PATH + NPI + '/ksdk/' + CPU + '/gcc/startup_' + CPU_WS + '.S', DEST_PATH + CPU_SDK + '/gcc')
					# shutil.copy(PATH + OUTPUT_PATH + NPI + '/ksdk_test_files/Test_' + CPU + '_registers.bat', DEST_PATH + CPU_SDK)
					# shutil.copy(PATH + OUTPUT_PATH + NPI + '/ksdk_test_files/Test_' + CPU + '_CMSIS.c', DEST_PATH + CPU_SDK)
					# Run test.bat in sdk repo
					os.chdir(DEST_PATH + CPU_SDK)
					test_bat = open('Test_' + CPU + '_registers.bat')
					test_lines = test_bat.readlines()
					partnumbers = []
					for test_line in test_lines:
						partnumbers.append(test_line.split('-DCPU_')[1].split(' ')[0])
					os.system('Test_' + CPU + '_registers.bat > ' + PATH + '/build_error_logs/' + NPI + '_' + CPU + '_log 2>&1')
					build_error = '0'
					for partnumber in partnumbers:
						if os.path.isfile('Test_' + partnumber + '.o'):
							os.remove('Test_'  + partnumber + '.o')
						else:
							build_error = '1'
					os.chdir(PATH)
					if build_error == '0':
						os.remove('build_error_logs/' + NPI + '_' + CPU + '_log')
					print 'Copy files and build for ' + NPI + ' ' + CPU + ' done'
if not os.listdir(PATH + '/build_error_logs'):
	shutil.rmtree(PATH + '/build_error_logs')
						
